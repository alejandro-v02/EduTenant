import { Building2, Map } from 'lucide-react';
import { Selector } from '../atomos/Selector';
import { CampoFormulario } from '../moleculas/CampoFormulario';
import { DEPARTAMENTOS_COLOMBIA, obtenerMunicipios } from '../../utilidades/colombia';

interface SelectorUbicacionProps {
  departamento: string;
  municipio: string;
  onCambiarDepartamento: (valor: string) => void;
  onCambiarMunicipio: (valor: string) => void;
  requerido?: boolean;
}

/** Par departamento/municipio de Colombia: al cambiar el departamento se limpia y filtra el municipio. */
export function SelectorUbicacion({
  departamento,
  municipio,
  onCambiarDepartamento,
  onCambiarMunicipio,
  requerido,
}: SelectorUbicacionProps) {
  const municipios = obtenerMunicipios(departamento);

  return (
    <>
      <CampoFormulario etiqueta="Departamento" icono={Map}>
        <Selector
          value={departamento}
          onChange={(e) => {
            onCambiarDepartamento(e.target.value);
            onCambiarMunicipio('');
          }}
          required={requerido}
        >
          <option value="">Selecciona un departamento</option>
          {DEPARTAMENTOS_COLOMBIA.map((d) => (
            <option key={d.departamento} value={d.departamento}>
              {d.departamento}
            </option>
          ))}
        </Selector>
      </CampoFormulario>
      <CampoFormulario etiqueta="Municipio" icono={Building2}>
        <Selector
          value={municipio}
          onChange={(e) => onCambiarMunicipio(e.target.value)}
          required={requerido}
          disabled={!departamento}
        >
          <option value="">{departamento ? 'Selecciona un municipio' : 'Elige primero un departamento'}</option>
          {municipios.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </Selector>
      </CampoFormulario>
    </>
  );
}
