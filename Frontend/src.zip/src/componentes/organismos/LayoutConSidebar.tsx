import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import type { LucideIcon } from 'lucide-react';
import { ChevronsLeft, GraduationCap } from 'lucide-react';
import { useSesion } from '../../autenticacion/useSesion';
import { MenuUsuario } from './MenuUsuario';
import { ModalPerfil } from './ModalPerfil';

export interface EnlaceNav {
  to: string;
  etiqueta: string;
  icono: LucideIcon;
  fin?: boolean;
}

interface LayoutConSidebarProps {
  tituloSeccion: string;
  enlaces: EnlaceNav[];
}

export function LayoutConSidebar({ tituloSeccion, enlaces }: LayoutConSidebarProps) {
  const { usuario } = useSesion();
  const [colapsada, setColapsada] = useState(false);
  const [perfilAbiertoManualmente, setPerfilAbiertoManualmente] = useState(false);

  const perfilObligatorio = Boolean(usuario && !usuario.perfilCompleto);
  const mostrarModalPerfil = perfilAbiertoManualmente || perfilObligatorio;

  return (
    <div className="layout">
      <aside className={`barra-lateral ${colapsada ? 'barra-lateral--colapsada' : ''}`}>
        <div className="barra-lateral__cabecera">
          <div className="barra-lateral__marca">
            <span className="barra-lateral__marca-icono">
              <GraduationCap size={17} />
            </span>
            <span className="barra-lateral__marca-texto">Skolar</span>
          </div>
          <button
            type="button"
            className="barra-lateral__toggle"
            onClick={() => setColapsada((valor) => !valor)}
            aria-label={colapsada ? 'Expandir menú' : 'Colapsar menú'}
          >
            <ChevronsLeft size={15} />
          </button>
        </div>

        <nav className="barra-lateral__nav">
          {enlaces.map((enlace) => (
            <NavLink
              key={enlace.to}
              to={enlace.to}
              end={enlace.fin}
              title={colapsada ? enlace.etiqueta : undefined}
              className={({ isActive }) => `barra-lateral__enlace ${isActive ? 'activo' : ''}`}
            >
              <enlace.icono size={18} />
              <span>{enlace.etiqueta}</span>
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="layout__principal">
        <header className="barra-superior">
          <h1>{tituloSeccion}</h1>
          <MenuUsuario onAbrirPerfil={() => setPerfilAbiertoManualmente(true)} />
        </header>
        <main className="layout__contenido">
          <Outlet />
        </main>
      </div>

      {mostrarModalPerfil && (
        <ModalPerfil obligatorio={perfilObligatorio} onCerrar={() => setPerfilAbiertoManualmente(false)} />
      )}
    </div>
  );
}
